package unsw.graphics.scene;

/**
 * A cool scene object
 *
 */
public class MyCoolSceneObject extends SceneObject {

    public MyCoolSceneObject(SceneObject parent) {
        super(parent);
        // TODO: Write your scene object
    }

}
